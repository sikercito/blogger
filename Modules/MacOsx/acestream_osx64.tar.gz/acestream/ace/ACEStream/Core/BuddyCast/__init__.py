#Embedded file name: ACEStream\Core\BuddyCast\__init__.pyo
pass
