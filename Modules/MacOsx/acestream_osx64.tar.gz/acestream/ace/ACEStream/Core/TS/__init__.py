#Embedded file name: ACEStream\Core\TS\__init__.pyo
pass
