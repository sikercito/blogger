#Embedded file name: ACEStream\Core\Ads\__init__.pyo
pass
