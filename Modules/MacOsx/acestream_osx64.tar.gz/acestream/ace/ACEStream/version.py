#Embedded file name: ACEStream\version.pyo
VERSION = '2.0.8.7'
VERSION_REV = '2191'
VERSION_DATE = '2013/03/28 18:36:41'
