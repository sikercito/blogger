#Embedded file name: ACEStream\Utilities\__init__.pyo
pass
