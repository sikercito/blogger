import sys
import os
#import android

#droid = android.Android()

#TODO: check for read-only filesystem

#try:
    #home_dir = droid.getAceStreamHome()
#except:
home_dir = "/sdcard"

try:
    sys.stderr = open(os.path.join(home_dir, "acestream_std.log"), 'w')
    sys.stdout = sys.stderr
except:
    pass

try:
    from acestreamengine import Core

    conf_file = os.path.join(home_dir, 'acestream.conf')
    print "try to load conf file", conf_file

    config = None
    if os.path.isfile(conf_file):
        import argparse
        parser = argparse.ArgumentParser(prog="acestream", fromfile_prefix_chars="@")

        parser.add_argument('--log-file', help="path to log file")
        parser.add_argument('--log-syslog', help="syslog host")
        parser.add_argument('--log-debug', help="", type=int, default=0)
        parser.add_argument('--log-modules', help="")
        parser.add_argument('--bind-all', help="", action="store_true")

        try:
            config, other = parser.parse_known_args(["@" + conf_file])
        except Exception, e:
            print "failed to load conf file: " + str(e)

    params = sys.argv[:]
    params.append('--client-console')

    if config is not None:
        if config.log_file is not None:
            params.extend(['--log-file', config.log_file])
        if config.log_syslog is not None:
            params.extend(['--log-syslog', config.log_syslog])
        if config.log_debug > 0:
            params.extend(['--log-debug', str(config.log_debug)])
        if config.log_modules is not None:
            params.extend(['--log-modules', config.log_modules])
        if config.bind_all:
            params.append('--bind-all')

    Core.run(params)

except Exception, e:
    import traceback
    import time

    try:
        f = open(os.path.join(home_dir, "acestream_error.log"), 'a')
        traceback.print_exc(file=f)
        f.close()
    except:
        pass

#    droid.makeToast("%r" % e)
    time.sleep(5)

